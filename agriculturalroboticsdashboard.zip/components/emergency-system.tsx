"use client"

import { useState, useEffect } from "react"
import useSWR from "swr"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  AlertTriangle,
  Shield,
  Phone,
  MapPin,
  Clock,
  Zap,
  Wifi,
  Battery,
  Thermometer,
  Droplets,
  Wind,
  Eye,
  CheckCircle,
  AlertCircle,
  Siren,
} from "lucide-react"
import { useRouter } from "next/navigation"

interface EmergencyAlert {
  id: string
  type: "critical" | "warning" | "info"
  category: "robot" | "irrigation" | "weather" | "security" | "system"
  title: string
  description: string
  location: string
  timestamp: string
  status: "active" | "acknowledged" | "resolved"
  severity: 1 | 2 | 3 | 4 | 5
  autoActions: string[]
}

const emergencyAlerts: EmergencyAlert[] = [
  {
    id: "ALERT-001",
    type: "critical",
    category: "robot",
    title: "Robot AGR-002 Unresponsive",
    description:
      "Lost communication with robot AGR-002. Last known location: Field B-2. Battery level was 45% at last contact.",
    location: "Field B-2",
    timestamp: "2 minutes ago",
    status: "active",
    severity: 5,
    autoActions: ["Emergency stop activated", "GPS tracking enabled", "Backup robot dispatched"],
  },
  {
    id: "ALERT-002",
    type: "warning",
    category: "irrigation",
    title: "Water Pressure Drop",
    description: "Significant pressure drop detected in Zone A-1. Possible pipe leak or blockage.",
    location: "Zone A-1",
    timestamp: "15 minutes ago",
    status: "acknowledged",
    severity: 3,
    autoActions: ["Zone isolation activated", "Flow monitoring increased"],
  },
  {
    id: "ALERT-003",
    type: "warning",
    category: "weather",
    title: "Severe Weather Warning",
    description: "Thunderstorm approaching. High winds and hail expected in 45 minutes.",
    location: "All Fields",
    timestamp: "30 minutes ago",
    status: "active",
    severity: 4,
    autoActions: ["Robots returning to shelter", "Irrigation systems secured"],
  },
  {
    id: "ALERT-004",
    type: "info",
    category: "system",
    title: "Scheduled Maintenance Due",
    description: "Sensor calibration overdue by 3 days. System performance may be affected.",
    location: "Field A-1",
    timestamp: "2 hours ago",
    status: "active",
    severity: 2,
    autoActions: ["Maintenance reminder sent", "Performance monitoring increased"],
  },
]

const emergencyContacts = [
  { name: "Farm Manager", phone: "+1 (555) 123-4567", role: "Primary" },
  { name: "Technical Support", phone: "+1 (555) 987-6543", role: "Technical" },
  { name: "Emergency Services", phone: "911", role: "Emergency" },
  { name: "Equipment Vendor", phone: "+1 (555) 456-7890", role: "Maintenance" },
]

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export function EmergencySystem() {
  const [emergencyMode, setEmergencyMode] = useState(false)
  const [selectedAlert, setSelectedAlert] = useState<EmergencyAlert | null>(null)
  const [showEmergencyDialog, setShowEmergencyDialog] = useState(false)
  const [showLocateDialog, setShowLocateDialog] = useState(false)
  const [showCallDialog, setShowCallDialog] = useState(false)
  const router = useRouter()

  useEffect(() => {
    try {
      // Next.js supports client navigation; prefetch if available
      // @ts-expect-error optional prefetch in Next.js
      router.prefetch?.("/emergency/stop")
    } catch {}
  }, [router])

  const { data: emergencyData } = useSWR<{ phone: string; name?: string }>("/api/emergency", fetcher)
  const { data: robotsData } = useSWR<{
    robots: Array<{
      id: string
      name: string
      x: number
      y: number
      z: number
      heading: number
      field: string
      lat?: number
      lng?: number
    }>
  }>("/api/robots", fetcher)

  const getAlertIcon = (type: EmergencyAlert["type"]) => {
    switch (type) {
      case "critical":
        return <AlertTriangle className="h-5 w-5 text-destructive" />
      case "warning":
        return <AlertCircle className="h-5 w-5 text-secondary" />
      case "info":
        return <Eye className="h-5 w-5 text-primary" />
    }
  }

  const getAlertBadge = (type: EmergencyAlert["type"]) => {
    switch (type) {
      case "critical":
        return <Badge variant="destructive">Critical</Badge>
      case "warning":
        return <Badge className="bg-secondary text-white">Warning</Badge>
      case "info":
        return <Badge variant="outline">Info</Badge>
    }
  }

  const getSeverityColor = (severity: number) => {
    if (severity >= 4) return "text-destructive"
    if (severity >= 3) return "text-secondary"
    return "text-primary"
  }

  const handleEmergencyStop = () => {
    setEmergencyMode(true)
    setShowEmergencyDialog(true)
  }

  const confirmEmergencyStop = () => {
    // Emergency stop logic would go here
    setShowEmergencyDialog(false)
    setEmergencyMode(true)
    router.push("/emergency/stop")
  }

  return (
    <div className="space-y-6">
      {/* Emergency Controls */}
      <Card className="border-destructive/20 bg-destructive/5">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Shield className="h-6 w-6 text-destructive" />
              <div>
                <CardTitle className="text-destructive">Emergency Control Center</CardTitle>
                <CardDescription>Critical system controls and emergency protocols</CardDescription>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant={emergencyMode ? "destructive" : "outline"}>
                {emergencyMode ? "EMERGENCY MODE ACTIVE" : "NORMAL OPERATION"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Dialog open={showEmergencyDialog} onOpenChange={setShowEmergencyDialog}>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-20 w-full bg-transparent border-destructive text-destructive font-semibold"
                  onClick={() => setShowEmergencyDialog(true)}
                >
                  <AlertTriangle className="h-6 w-6 mr-2" />
                  EMERGENCY STOP
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle className="text-destructive">Confirm Emergency Stop</DialogTitle>
                  <DialogDescription>
                    This will immediately stop all robots and irrigation systems. This action cannot be undone.
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowEmergencyDialog(false)}>
                    Cancel
                  </Button>
                  <Button variant="destructive" onClick={confirmEmergencyStop}>
                    Confirm Emergency Stop
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Dialog open={showCallDialog} onOpenChange={setShowCallDialog}>
              <DialogTrigger asChild>
                <Button
                  variant="outline"
                  size="lg"
                  className="h-20 w-full bg-transparent"
                  onClick={() => setShowCallDialog(true)}
                  aria-label={`Open call dialog for ${emergencyData?.name || "Emergency Contact"}`}
                >
                  <Phone className="h-6 w-6 mr-2" />
                  <span>Call Emergency</span>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Call Emergency Contact</DialogTitle>
                  <DialogDescription>
                    {emergencyData?.name || "Emergency Contact"} • {emergencyData?.phone || "+91 8591619938"}
                  </DialogDescription>
                </DialogHeader>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setShowCallDialog(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      const phoneRaw = emergencyData?.phone || "+91 8591619938"
                      const phone = phoneRaw.replace(/[^\d+]/g, "")
                      if (typeof window !== "undefined") window.location.href = `tel:${phone}`
                    }}
                  >
                    Call Now
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Button variant="outline" size="lg" className="h-20 w-full bg-transparent">
              <Siren className="h-6 w-6 mr-2" />
              Sound Alarm
            </Button>

            <Button
              variant="outline"
              size="lg"
              className="h-20 w-full bg-transparent"
              onClick={() => setShowLocateDialog(true)}
            >
              <MapPin className="h-6 w-6 mr-2" />
              Locate All Robots
            </Button>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="alerts" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="alerts">Active Alerts</TabsTrigger>
          <TabsTrigger value="protocols">Protocols</TabsTrigger>
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        <TabsContent value="alerts" className="space-y-6">
          {/* Alert Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-destructive" />
                  <div>
                    <p className="text-sm text-muted-foreground">Critical</p>
                    <p className="text-2xl font-bold text-destructive">1</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-secondary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Warnings</p>
                    <p className="text-2xl font-bold text-secondary">2</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Eye className="h-5 w-5 text-primary" />
                  <div>
                    <p className="text-sm text-muted-foreground">Info</p>
                    <p className="text-2xl font-bold text-primary">1</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-chart-4" />
                  <div>
                    <p className="text-sm text-muted-foreground">Resolved Today</p>
                    <p className="text-2xl font-bold text-chart-4">7</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Active Alerts List */}
          <Card>
            <CardHeader>
              <CardTitle>Active Alerts</CardTitle>
              <CardDescription>Current system alerts requiring attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {emergencyAlerts.map((alert) => (
                  <Card
                    key={alert.id}
                    className={`cursor-pointer transition-all hover:shadow-md ${
                      alert.type === "critical"
                        ? "border-destructive/50 bg-destructive/5"
                        : alert.type === "warning"
                          ? "border-secondary/50 bg-secondary/5"
                          : "border-primary/50 bg-primary/5"
                    }`}
                    onClick={() => setSelectedAlert(alert)}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          {getAlertIcon(alert.type)}
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className="font-medium">{alert.title}</h4>
                              {getAlertBadge(alert.type)}
                              <Badge variant="outline" className={getSeverityColor(alert.severity)}>
                                Level {alert.severity}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground mb-2">{alert.description}</p>
                            <div className="flex items-center gap-4 text-xs text-muted-foreground">
                              <div className="flex items-center gap-1">
                                <MapPin className="h-3 w-3" />
                                <span>{alert.location}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-3 w-3" />
                                <span>{alert.timestamp}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            Acknowledge
                          </Button>
                          <Button variant="outline" size="sm">
                            Resolve
                          </Button>
                        </div>
                      </div>

                      {alert.autoActions.length > 0 && (
                        <div className="mt-3 pt-3 border-t">
                          <p className="text-xs font-medium text-muted-foreground mb-1">Auto Actions Taken:</p>
                          <div className="flex flex-wrap gap-1">
                            {alert.autoActions.map((action, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {action}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="protocols" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Emergency Protocols</CardTitle>
                <CardDescription>Automated response procedures</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {[
                  {
                    trigger: "Robot Communication Lost",
                    actions: ["Activate GPS tracking", "Send backup robot", "Alert farm manager", "Log incident"],
                  },
                  {
                    trigger: "Severe Weather Alert",
                    actions: [
                      "Return robots to shelter",
                      "Secure irrigation systems",
                      "Close greenhouse vents",
                      "Alert staff",
                    ],
                  },
                  {
                    trigger: "Water System Failure",
                    actions: [
                      "Isolate affected zones",
                      "Switch to backup pumps",
                      "Alert maintenance team",
                      "Monitor soil moisture",
                    ],
                  },
                  {
                    trigger: "Security Breach",
                    actions: ["Lock down systems", "Activate cameras", "Alert security", "Log all access attempts"],
                  },
                ].map((protocol, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <h4 className="font-medium mb-2">{protocol.trigger}</h4>
                      <div className="space-y-1">
                        {protocol.actions.map((action, actionIndex) => (
                          <div key={actionIndex} className="flex items-center gap-2 text-sm">
                            <CheckCircle className="h-3 w-3 text-primary" />
                            <span>{action}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Critical system monitoring</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Wifi className="h-4 w-4" />
                        <span className="text-sm">Network</span>
                      </div>
                      <Badge variant="default">Online</Badge>
                    </div>
                    <Progress value={98} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4" />
                        <span className="text-sm">Power</span>
                      </div>
                      <Badge variant="default">Stable</Badge>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Battery className="h-4 w-4" />
                        <span className="text-sm">Backup Power</span>
                      </div>
                      <Badge variant="default">Ready</Badge>
                    </div>
                    <Progress value={100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Shield className="h-4 w-4" />
                        <span className="text-sm">Security</span>
                      </div>
                      <Badge variant="default">Armed</Badge>
                    </div>
                    <Progress value={100} className="h-2" />
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">Environmental Conditions</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4" />
                        <span>Temperature</span>
                      </div>
                      <span className="font-medium">22°C</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Droplets className="h-4 w-4" />
                        <span>Humidity</span>
                      </div>
                      <span className="font-medium">65%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Wind className="h-4 w-4" />
                        <span>Wind Speed</span>
                      </div>
                      <span className="font-medium">13 km/h</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Eye className="h-4 w-4" />
                        <span>Visibility</span>
                      </div>
                      <span className="font-medium">Clear</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Emergency Contacts</CardTitle>
                <CardDescription>Quick access to emergency personnel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {emergencyContacts.map((contact, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div>
                      <p className="font-medium">{contact.name}</p>
                      <p className="text-sm text-muted-foreground">{contact.role}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4 mr-2" />
                        {contact.phone}
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Add Emergency Contact</CardTitle>
                <CardDescription>Configure additional emergency contacts</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input placeholder="Contact name" />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input placeholder="+1 (555) 123-4567" />
                </div>
                <div className="space-y-2">
                  <Label>Role</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="primary">Primary Contact</SelectItem>
                      <SelectItem value="technical">Technical Support</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="emergency">Emergency Services</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Notes</Label>
                  <Textarea placeholder="Additional information..." />
                </div>
                <Button className="w-full">Add Contact</Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Alert History</CardTitle>
              <CardDescription>Recent emergency alerts and responses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { time: "2 hours ago", type: "resolved", title: "Irrigation pump failure", duration: "45 minutes" },
                  { time: "1 day ago", type: "resolved", title: "Robot battery critical", duration: "12 minutes" },
                  { time: "2 days ago", type: "resolved", title: "Network connectivity issue", duration: "2 hours" },
                  { time: "3 days ago", type: "resolved", title: "Sensor calibration error", duration: "30 minutes" },
                  { time: "1 week ago", type: "resolved", title: "Weather emergency protocol", duration: "3 hours" },
                ].map((item, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-5 w-5 text-primary" />
                      <div>
                        <p className="font-medium">{item.title}</p>
                        <p className="text-sm text-muted-foreground">
                          {item.time} • Duration: {item.duration}
                        </p>
                      </div>
                    </div>
                    <Badge variant="outline">Resolved</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Locate Robots Dialog */}
      <Dialog open={showLocateDialog} onOpenChange={setShowLocateDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Robot Locations (Field Map)</DialogTitle>
            <DialogDescription>Positions relative to field boundaries defined in the Field Map.</DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            {(robotsData?.robots || []).map((r) => {
              const fallbackLat = 27.1067
              const fallbackLng = 88.3233
              const lat = r.lat ?? fallbackLat
              const lng = r.lng ?? fallbackLng
              const label = encodeURIComponent(`${r.name} - Jorethang`)
              const mapsUrl = `https://www.google.com/maps/search/?api=1&query=${lat},${lng} (${label})`

              return (
                <div
                  key={r.id}
                  className="flex items-start justify-between p-3 bg-muted/50 rounded-lg cursor-pointer"
                  role="button"
                  tabIndex={0}
                  onClick={() => window.open(mapsUrl, "_blank", "noopener,noreferrer")}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" || e.key === " ") window.open(mapsUrl, "_blank", "noopener,noreferrer")
                  }}
                  aria-label={`Open ${r.name} in Google Maps (Jorethang region)`}
                >
                  <div>
                    <p className="font-medium underline">
                      {r.name} <span className="text-muted-foreground">({r.id})</span>
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Field: <span className="font-medium">{r.field}</span>
                    </p>
                    <p className="text-sm text-muted-foreground">
                      Coords:{" "}
                      <span className="font-mono">
                        {r.x}, {r.y}, z:{r.z}
                      </span>{" "}
                      • Heading: {r.heading}°
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">Located</Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        window.open(mapsUrl, "_blank", "noopener,noreferrer")
                      }}
                      aria-label={`Open ${r.name} in Google Maps`}
                    >
                      <MapPin className="h-4 w-4 mr-1" />
                      Open in Maps
                    </Button>
                  </div>
                </div>
              )
            })}
            {!robotsData?.robots?.length && <p className="text-sm text-muted-foreground">Loading robot positions...</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLocateDialog(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
