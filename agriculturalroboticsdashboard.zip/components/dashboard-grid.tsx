"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { RobotMonitoring } from "@/components/robot-monitoring"
import { CropAnalytics } from "@/components/crop-analytics"
import { IrrigationControls } from "@/components/irrigation-controls"
import { EmergencySystem } from "@/components/emergency-system"
import { Tractor, Droplets, Thermometer, Cloud, TrendingUp, MapPin, Battery, Wifi } from "lucide-react"

export function DashboardGrid() {
  return (
    <Tabs defaultValue="overview" className="w-full">
      <TabsList className="grid w-full grid-cols-5">
        <TabsTrigger value="overview">Overview</TabsTrigger>
        <TabsTrigger value="robots">Robot Fleet</TabsTrigger>
        <TabsTrigger value="analytics">Analytics</TabsTrigger>
        <TabsTrigger value="irrigation">Irrigation</TabsTrigger>
        <TabsTrigger value="alerts">Alerts</TabsTrigger>
      </TabsList>

      <TabsContent value="overview" className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {/* Weather Card */}
          <Card className="col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Cloud className="h-5 w-5 text-primary" />
                Weather
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold">22°C</span>
                  <Badge variant="secondary">Sunny</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="flex items-center gap-1">
                    <Thermometer className="h-3 w-3" />
                    <span>Humidity: 65%</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Droplets className="h-3 w-3" />
                    <span>Rain: 0%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Active Robots */}
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Tractor className="h-5 w-5 text-primary" />
                Active Robots
              </CardTitle>
              <CardDescription>2 robots currently operational</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { id: "AGR-001", status: "Irrigating", battery: 85, location: "Field A-1" },
                  { id: "AGR-002", status: "Mapping", battery: 92, location: "Field B-2" },
                ].map((robot) => (
                  <div key={robot.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 bg-primary rounded-full animate-pulse"></div>
                      <div>
                        <p className="font-medium">{robot.id}</p>
                        <p className="text-sm text-muted-foreground">{robot.status}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        <span className="text-xs">{robot.location}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Battery className="h-3 w-3" />
                        <span className="text-xs">{robot.battery}%</span>
                      </div>
                      <Badge variant={robot.battery > 70 ? "default" : "destructive"}>
                        {robot.battery > 70 ? "Good" : "Low"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* System Health */}
          <Card className="col-span-1">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <Wifi className="h-5 w-5 text-primary" />
                System Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Network</span>
                    <span>98%</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Sensors</span>
                    <span>94%</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Storage</span>
                    <span>76%</span>
                  </div>
                  <Progress value={76} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card className="col-span-1 md:col-span-2">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-primary" />
                Today's Overview
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">1.5</p>
                  <p className="text-sm text-muted-foreground">Acres Covered</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-secondary">350</p>
                  <p className="text-sm text-muted-foreground">Litres Used</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-chart-3">2</p>
                  <p className="text-sm text-muted-foreground">Issues Detected</p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-chart-4">95%</p>
                  <p className="text-sm text-muted-foreground">Efficiency</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </TabsContent>

      <TabsContent value="robots" className="space-y-6">
        <RobotMonitoring />
      </TabsContent>

      <TabsContent value="analytics" className="space-y-6">
        <CropAnalytics />
      </TabsContent>

      <TabsContent value="irrigation" className="space-y-6">
        <IrrigationControls />
      </TabsContent>

      <TabsContent value="alerts" className="space-y-6">
        <EmergencySystem />
      </TabsContent>
    </Tabs>
  )
}
