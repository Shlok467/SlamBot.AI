"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tractor, Droplets, BarChart3, Map, AlertTriangle, Settings, ChevronLeft, ChevronRight } from "lucide-react"

interface SidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

export function Sidebar({ activeSection, onSectionChange }: SidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(false)

  const menuItems = [
    { icon: "Tractor", label: "Robot Fleet", section: "robot-fleet", count: 2 },
    { icon: "BarChart3", label: "Analytics", section: "analytics" },
    { icon: "Droplets", label: "Irrigation", section: "irrigation", count: 2 },
    { icon: "Map", label: "Field Map", section: "field-map" },
    { icon: "AlertTriangle", label: "Alerts", section: "alerts", count: 1 },
    { icon: "Settings", label: "Settings", section: "settings" },
  ]

  const getIcon = (iconName: string) => {
    const iconMap = {
      Tractor: Tractor,
      BarChart3: BarChart3,
      Droplets: Droplets,
      Map: Map,
      AlertTriangle: AlertTriangle,
      Settings: Settings,
    }
    const IconComponent = iconMap[iconName as keyof typeof iconMap]
    return IconComponent ? <IconComponent className={`h-4 w-4 ${isCollapsed ? "" : "mr-3"}`} /> : null
  }

  return (
    <Card className={`${isCollapsed ? "w-16" : "w-64"} h-full rounded-none border-r transition-all duration-300`}>
      <div className="p-4 border-b">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div>
              <h2 className="text-lg font-semibold text-primary">AgriBot</h2>
              <p className="text-sm text-muted-foreground">Farm Dashboard</p>
            </div>
          )}
          <Button variant="ghost" size="sm" onClick={() => setIsCollapsed(!isCollapsed)} className="ml-auto">
            {isCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      <nav className="p-4 space-y-2">
        <Button
          variant={activeSection === "dashboard" ? "default" : "ghost"}
          className={`w-full justify-start ${isCollapsed ? "px-2" : "px-4"}`}
          size={isCollapsed ? "sm" : "default"}
          onClick={() => onSectionChange("dashboard")}
        >
          <BarChart3 className={`h-4 w-4 ${isCollapsed ? "" : "mr-3"}`} />
          {!isCollapsed && <span className="flex-1 text-left">Dashboard</span>}
        </Button>

        {menuItems.map((item, index) => (
          <Button
            key={index}
            variant={activeSection === item.section ? "default" : "ghost"}
            className={`w-full justify-start ${isCollapsed ? "px-2" : "px-4"}`}
            size={isCollapsed ? "sm" : "default"}
            onClick={() => onSectionChange(item.section)}
          >
            {getIcon(item.icon)}
            {!isCollapsed && (
              <>
                <span className="flex-1 text-left">{item.label}</span>
                {item.count && (
                  <Badge variant="secondary" className="ml-auto">
                    {item.count}
                  </Badge>
                )}
              </>
            )}
          </Button>
        ))}
      </nav>
    </Card>
  )
}
