"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import {
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Move3D,
  Maximize,
  Download,
  Settings,
  Compass,
  Grid3X3,
  Mountain,
  Tractor,
  Droplets,
} from "lucide-react"

interface FieldData {
  id: string
  name: string
  coordinates: { x: number; y: number; z: number }[]
  cropType: string
  healthScore: number
  moistureLevel: number
  lastUpdated: string
}

interface RobotPosition {
  id: string
  name: string
  x: number
  y: number
  z: number
  status: "active" | "idle" | "charging"
  heading: number
}

interface IrrigationZone {
  id: string
  name: string
  center: { x: number; y: number }
  radius: number
  status: "active" | "idle" | "scheduled"
  coverage: number
}

const mockFields: FieldData[] = [
  {
    id: "field-a1",
    name: "Field A-1",
    coordinates: [
      { x: 0, y: 0, z: 0 },
      { x: 100, y: 0, z: 2 },
      { x: 100, y: 80, z: 1 },
      { x: 0, y: 80, z: 0 },
    ],
    cropType: "Corn",
    healthScore: 92,
    moistureLevel: 65,
    lastUpdated: "2 hours ago",
  },
  {
    id: "field-a2",
    name: "Field A-2",
    coordinates: [
      { x: 110, y: 0, z: 1 },
      { x: 200, y: 0, z: 3 },
      { x: 200, y: 80, z: 2 },
      { x: 110, y: 80, z: 1 },
    ],
    cropType: "Ginger",
    healthScore: 88,
    moistureLevel: 58,
    lastUpdated: "1 hour ago",
  },
  {
    id: "field-b1",
    name: "Field B-1",
    coordinates: [
      { x: 0, y: 90, z: 0 },
      { x: 100, y: 90, z: 1 },
      { x: 100, y: 170, z: 2 },
      { x: 0, y: 170, z: 1 },
    ],
    cropType: "Wheat",
    healthScore: 95,
    moistureLevel: 72,
    lastUpdated: "30 minutes ago",
  },
]

const mockRobots: RobotPosition[] = [
  { id: "AGR-001", name: "Alpha Bot", x: 45, y: 40, z: 1, status: "active", heading: 45 },
  { id: "AGR-002", name: "Beta Bot", x: 155, y: 45, z: 2, status: "active", heading: 180 },
]

const mockIrrigationZones: IrrigationZone[] = [
  { id: "zone-1", name: "North Sprinklers", center: { x: 50, y: 40 }, radius: 25, status: "active", coverage: 85 },
  { id: "zone-2", name: "East Sprinklers", center: { x: 155, y: 40 }, radius: 30, status: "idle", coverage: 92 },
  { id: "zone-3", name: "South Sprinklers", center: { x: 50, y: 130 }, radius: 28, status: "scheduled", coverage: 78 },
]

export function FieldMap3D() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [viewMode, setViewMode] = useState<"2d" | "3d">("3d")
  const [selectedLayer, setSelectedLayer] = useState("all")
  const [showRobots, setShowRobots] = useState(true)
  const [showIrrigation, setShowIrrigation] = useState(true)
  const [showElevation, setShowElevation] = useState(true)
  const [showGrid, setShowGrid] = useState(false)
  const [zoom, setZoom] = useState([100])
  const [rotation, setRotation] = useState([45])
  const [tilt, setTilt] = useState([30])

  // Simple 3D visualization using Canvas 2D API
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set up coordinate system
    const centerX = canvas.width / 2
    const centerY = canvas.height / 2
    const scale = zoom[0] / 100

    // Helper function to project 3D to 2D
    const project3D = (x: number, y: number, z: number) => {
      const rotRad = (rotation[0] * Math.PI) / 180
      const tiltRad = (tilt[0] * Math.PI) / 180

      // Rotate around Y axis
      const rotatedX = x * Math.cos(rotRad) - y * Math.sin(rotRad)
      const rotatedY = x * Math.sin(rotRad) + y * Math.cos(rotRad)
      const rotatedZ = z

      // Apply tilt
      const finalY = rotatedY * Math.cos(tiltRad) - rotatedZ * Math.sin(tiltRad)
      const finalZ = rotatedY * Math.sin(tiltRad) + rotatedZ * Math.cos(tiltRad)

      return {
        x: centerX + rotatedX * scale,
        y: centerY + finalY * scale,
        z: finalZ,
      }
    }

    // Draw grid if enabled
    if (showGrid) {
      ctx.strokeStyle = document.documentElement.classList.contains("dark") ? "#374151" : "#e5e7eb"
      ctx.lineWidth = 1
      for (let i = -200; i <= 200; i += 20) {
        const start = project3D(i, -200, 0)
        const end = project3D(i, 200, 0)
        ctx.beginPath()
        ctx.moveTo(start.x, start.y)
        ctx.lineTo(end.x, end.y)
        ctx.stroke()

        const start2 = project3D(-200, i, 0)
        const end2 = project3D(200, i, 0)
        ctx.beginPath()
        ctx.moveTo(start2.x, start2.y)
        ctx.lineTo(end2.x, end2.y)
        ctx.stroke()
      }
    }

    // Draw fields
    mockFields.forEach((field) => {
      const projectedCoords = field.coordinates.map((coord) => project3D(coord.x, coord.y, coord.z))

      // Fill field based on health score
      const healthColor = field.healthScore > 90 ? "#4B8E3B" : field.healthScore > 75 ? "#D9B300" : "#FF6B6B"
      ctx.fillStyle = healthColor + "40" // Add transparency
      ctx.strokeStyle = healthColor
      ctx.lineWidth = 2

      ctx.beginPath()
      ctx.moveTo(projectedCoords[0].x, projectedCoords[0].y)
      projectedCoords.slice(1).forEach((coord) => {
        ctx.lineTo(coord.x, coord.y)
      })
      ctx.closePath()
      ctx.fill()
      ctx.stroke()

      // Add field label
      const centerCoord = projectedCoords.reduce(
        (acc, coord) => ({ x: acc.x + coord.x / projectedCoords.length, y: acc.y + coord.y / projectedCoords.length }),
        { x: 0, y: 0 },
      )
      ctx.fillStyle = document.documentElement.classList.contains("dark") ? "#f9fafb" : "#000"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.fillText(field.name, centerCoord.x, centerCoord.y)
    })

    // Draw irrigation zones if enabled
    if (showIrrigation) {
      mockIrrigationZones.forEach((zone) => {
        const center = project3D(zone.center.x, zone.center.y, 0)
        const radiusProjected = zone.radius * scale

        ctx.strokeStyle = zone.status === "active" ? "#4B8E3B" : zone.status === "scheduled" ? "#D9B300" : "#9CA3AF"
        ctx.fillStyle = ctx.strokeStyle + "20"
        ctx.lineWidth = 2
        ctx.setLineDash([5, 5])

        ctx.beginPath()
        ctx.arc(center.x, center.y, radiusProjected, 0, 2 * Math.PI)
        ctx.fill()
        ctx.stroke()
        ctx.setLineDash([])

        // Add irrigation icon
        ctx.fillStyle = ctx.strokeStyle
        ctx.font = "16px sans-serif"
        ctx.textAlign = "center"
        ctx.fillText("💧", center.x, center.y + 5)
      })
    }

    // Draw robots if enabled
    if (showRobots) {
      mockRobots.forEach((robot) => {
        const pos = project3D(robot.x, robot.y, robot.z)

        // Robot body
        const robotColor = robot.status === "active" ? "#4B8E3B" : robot.status === "charging" ? "#D9B300" : "#9CA3AF"
        ctx.fillStyle = robotColor
        ctx.strokeStyle = robotColor
        ctx.lineWidth = 2

        ctx.beginPath()
        ctx.arc(pos.x, pos.y, 8, 0, 2 * Math.PI)
        ctx.fill()
        ctx.stroke()

        // Robot direction indicator
        const headingRad = (robot.heading * Math.PI) / 180
        const dirX = pos.x + Math.cos(headingRad) * 12
        const dirY = pos.y + Math.sin(headingRad) * 12

        ctx.beginPath()
        ctx.moveTo(pos.x, pos.y)
        ctx.lineTo(dirX, dirY)
        ctx.stroke()

        // Robot label
        ctx.fillStyle = document.documentElement.classList.contains("dark") ? "#f9fafb" : "#000"
        ctx.font = "10px sans-serif"
        ctx.textAlign = "center"
        ctx.fillText(robot.name, pos.x, pos.y - 15)
      })
    }
  }, [viewMode, zoom, rotation, tilt, showRobots, showIrrigation, showElevation, showGrid])

  const resetView = () => {
    setZoom([100])
    setRotation([45])
    setTilt([30])
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-col lg:flex-row gap-4 items-start lg:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-primary">3D Field Visualization</h2>
          <p className="text-muted-foreground">Interactive field mapping with real-time robot tracking</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select value={selectedLayer} onValueChange={setSelectedLayer}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select layer" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Layers</SelectItem>
              <SelectItem value="fields">Fields Only</SelectItem>
              <SelectItem value="robots">Robots Only</SelectItem>
              <SelectItem value="irrigation">Irrigation Only</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={resetView}>
            <RotateCcw className="h-4 w-4 mr-2" />
            Reset View
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* 3D Visualization */}
        <Card className="lg:col-span-3">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Mountain className="h-5 w-5 text-primary" />
                Field Map
              </CardTitle>
              <div className="flex gap-2">
                <Button variant={viewMode === "2d" ? "default" : "outline"} size="sm" onClick={() => setViewMode("2d")}>
                  2D
                </Button>
                <Button variant={viewMode === "3d" ? "default" : "outline"} size="sm" onClick={() => setViewMode("3d")}>
                  3D
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <canvas
                ref={canvasRef}
                className="w-full h-96 border rounded-lg bg-gradient-to-b from-sky-100 to-green-50 dark:from-slate-800 dark:to-slate-700"
                style={{ minHeight: "400px" }}
              />

              {/* Map Legend */}
              <div className="absolute top-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 space-y-2 border">
                <h4 className="font-medium text-sm text-foreground">Legend</h4>
                <div className="space-y-1 text-xs text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary rounded"></div>
                    <span>Healthy Crops (90%+)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-secondary rounded"></div>
                    <span>Good Crops (75-89%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-chart-3 rounded"></div>
                    <span>Poor Crops (&lt;75%)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span>Active Robot</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 border-2 border-primary rounded-full"></div>
                    <span>Irrigation Zone</span>
                  </div>
                </div>
              </div>

              {/* Compass */}
              <div className="absolute top-4 right-4 bg-background/90 backdrop-blur-sm rounded-lg p-2 border">
                <Compass className="h-8 w-8 text-primary" style={{ transform: `rotate(${rotation[0]}deg)` }} />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Controls Panel */}
        <Card className="lg:col-span-1">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5 text-primary" />
              View Controls
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* View Controls */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Zoom Level</Label>
                <Slider value={zoom} onValueChange={setZoom} min={50} max={200} step={10} className="w-full" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>50%</span>
                  <span>{zoom[0]}%</span>
                  <span>200%</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Rotation</Label>
                <Slider value={rotation} onValueChange={setRotation} min={0} max={360} step={5} className="w-full" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0°</span>
                  <span>{rotation[0]}°</span>
                  <span>360°</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Tilt</Label>
                <Slider value={tilt} onValueChange={setTilt} min={0} max={90} step={5} className="w-full" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>0°</span>
                  <span>{tilt[0]}°</span>
                  <span>90°</span>
                </div>
              </div>
            </div>

            {/* Layer Controls */}
            <div className="space-y-3">
              <Label>Visible Layers</Label>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Switch id="robots" checked={showRobots} onCheckedChange={setShowRobots} />
                  <Label htmlFor="robots" className="flex items-center gap-2">
                    <Tractor className="h-4 w-4" />
                    Robots
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="irrigation" checked={showIrrigation} onCheckedChange={setShowIrrigation} />
                  <Label htmlFor="irrigation" className="flex items-center gap-2">
                    <Droplets className="h-4 w-4" />
                    Irrigation
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="elevation" checked={showElevation} onCheckedChange={setShowElevation} />
                  <Label htmlFor="elevation" className="flex items-center gap-2">
                    <Mountain className="h-4 w-4" />
                    Elevation
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="grid" checked={showGrid} onCheckedChange={setShowGrid} />
                  <Label htmlFor="grid" className="flex items-center gap-2">
                    <Grid3X3 className="h-4 w-4" />
                    Grid
                  </Label>
                </div>
              </div>
            </div>

            {/* Quick Actions */}
            <div className="space-y-2">
              <Label>Quick Actions</Label>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm">
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Move3D className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm">
                  <Maximize className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Field Information */}
      <Tabs defaultValue="fields" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="fields">Field Data</TabsTrigger>
          <TabsTrigger value="robots">Robot Positions</TabsTrigger>
          <TabsTrigger value="zones">Irrigation Zones</TabsTrigger>
        </TabsList>

        <TabsContent value="fields" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockFields.map((field) => (
              <Card key={field.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span>{field.name}</span>
                    <Badge
                      variant={
                        field.healthScore > 90 ? "default" : field.healthScore > 75 ? "secondary" : "destructive"
                      }
                    >
                      {field.healthScore}%
                    </Badge>
                  </CardTitle>
                  <CardDescription>{field.cropType}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Health Score</span>
                      <span className="font-medium">{field.healthScore}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Moisture Level</span>
                      <span className="font-medium">{field.moistureLevel}%</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Last Updated</span>
                      <span className="font-medium">{field.lastUpdated}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="robots" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockRobots.map((robot) => (
              <Card key={robot.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span>{robot.name}</span>
                    <Badge
                      variant={
                        robot.status === "active" ? "default" : robot.status === "charging" ? "secondary" : "outline"
                      }
                    >
                      {robot.status}
                    </Badge>
                  </CardTitle>
                  <CardDescription>{robot.id}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Position</span>
                      <span className="font-medium">
                        {robot.x}, {robot.y}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Elevation</span>
                      <span className="font-medium">{robot.z}m</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Heading</span>
                      <span className="font-medium">{robot.heading}°</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="zones" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mockIrrigationZones.map((zone) => (
              <Card key={zone.id}>
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center justify-between">
                    <span>{zone.name}</span>
                    <Badge
                      variant={
                        zone.status === "active" ? "default" : zone.status === "scheduled" ? "secondary" : "outline"
                      }
                    >
                      {zone.status}
                    </Badge>
                  </CardTitle>
                  <CardDescription>{zone.id}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Center Position</span>
                      <span className="font-medium">
                        {zone.center.x}, {zone.center.y}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Coverage Radius</span>
                      <span className="font-medium">{zone.radius}m</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Coverage</span>
                      <span className="font-medium">{zone.coverage}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
