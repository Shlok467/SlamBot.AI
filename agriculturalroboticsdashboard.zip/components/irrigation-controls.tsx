"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts"
import {
  Droplets,
  Play,
  Pause,
  Square,
  Timer,
  Gauge,
  Calendar,
  Clock,
  Settings,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  Zap,
} from "lucide-react"

interface IrrigationZone {
  id: string
  name: string
  field: string
  status: "active" | "idle" | "scheduled" | "maintenance"
  soilMoisture: number
  waterFlow: number
  pressure: number
  duration: number
  lastWatered: string
  nextScheduled: string
  waterUsed: number
  efficiency: number
}

const irrigationZones: IrrigationZone[] = [
  {
    id: "ZONE-A1",
    name: "North Section",
    field: "Field A-1",
    status: "active",
    soilMoisture: 45,
    waterFlow: 25.5,
    pressure: 32,
    duration: 45,
    lastWatered: "2 hours ago",
    nextScheduled: "Tomorrow 6:00 AM",
    waterUsed: 120, // litres
    efficiency: 92,
  },
  {
    id: "ZONE-A2",
    name: "South Section",
    field: "Field A-2",
    status: "scheduled",
    soilMoisture: 62,
    waterFlow: 0,
    pressure: 28,
    duration: 30,
    lastWatered: "Yesterday",
    nextScheduled: "Today 8:00 PM",
    waterUsed: 95, // litres
    efficiency: 88,
  },
  {
    id: "ZONE-B1",
    name: "East Section",
    field: "Field B-1",
    status: "idle",
    soilMoisture: 78,
    waterFlow: 0,
    pressure: 30,
    duration: 0,
    lastWatered: "3 hours ago",
    nextScheduled: "Tomorrow 7:00 AM",
    waterUsed: 135, // litres
    efficiency: 95,
  },
  {
    id: "ZONE-B2",
    name: "West Section",
    field: "Field B-2",
    status: "maintenance",
    soilMoisture: 35,
    waterFlow: 0,
    pressure: 0,
    duration: 0,
    lastWatered: "2 days ago",
    nextScheduled: "Pending repair",
    waterUsed: 0, // litres
    efficiency: 0,
  },
]

const waterUsageData = [
  { day: "Mon", usage: 320, target: 350 },
  { day: "Tue", usage: 290, target: 350 },
  { day: "Wed", usage: 360, target: 350 },
  { day: "Thu", usage: 310, target: 350 },
  { day: "Fri", usage: 340, target: 350 },
  { day: "Sat", usage: 275, target: 350 },
  { day: "Sun", usage: 350, target: 350 },
]

const moistureData = [
  { time: "00:00", fieldA: 65, fieldB: 72, fieldC: 58 },
  { time: "04:00", fieldA: 62, fieldB: 69, fieldC: 55 },
  { time: "08:00", fieldA: 58, fieldB: 65, fieldC: 52 },
  { time: "12:00", fieldA: 45, fieldB: 58, fieldC: 48 },
  { time: "16:00", fieldA: 42, fieldB: 55, fieldC: 45 },
  { time: "20:00", fieldA: 48, fieldB: 62, fieldC: 50 },
]

export function IrrigationControls() {
  const [selectedZone, setSelectedZone] = useState<IrrigationZone>(irrigationZones[0])
  const [manualDuration, setManualDuration] = useState([30])
  const [autoMode, setAutoMode] = useState(true)

  const getStatusColor = (status: IrrigationZone["status"]) => {
    switch (status) {
      case "active":
        return "bg-primary"
      case "scheduled":
        return "bg-secondary"
      case "idle":
        return "bg-muted"
      case "maintenance":
        return "bg-destructive"
      default:
        return "bg-muted"
    }
  }

  const getStatusBadge = (status: IrrigationZone["status"]) => {
    switch (status) {
      case "active":
        return <Badge className="bg-primary">Active</Badge>
      case "scheduled":
        return <Badge className="bg-secondary text-white">Scheduled</Badge>
      case "idle":
        return <Badge variant="outline">Idle</Badge>
      case "maintenance":
        return <Badge variant="destructive">Maintenance</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getMoistureColor = (moisture: number) => {
    if (moisture < 40) return "text-destructive"
    if (moisture < 60) return "text-secondary"
    return "text-primary"
  }

  return (
    <div className="space-y-6">
      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Active Zones</p>
                <p className="text-2xl font-bold text-primary">1/4</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-secondary" />
              <div>
                <p className="text-sm text-muted-foreground">Water Used Today</p>
                <p className="text-2xl font-bold text-secondary">350 L</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Gauge className="h-5 w-5 text-chart-3" />
              <div>
                <p className="text-sm text-muted-foreground">Avg Pressure</p>
                <p className="text-2xl font-bold text-chart-3">30 PSI</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-chart-4" />
              <div>
                <p className="text-sm text-muted-foreground">Efficiency</p>
                <p className="text-2xl font-bold text-chart-4">91%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="zones" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="zones">Zone Control</TabsTrigger>
          <TabsTrigger value="schedule">Scheduling</TabsTrigger>
          <TabsTrigger value="monitoring">Monitoring</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="zones" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Zone Selection */}
            <div className="lg:col-span-1 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Irrigation Zones</CardTitle>
                  <CardDescription>Select a zone to control</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {irrigationZones.map((zone) => (
                    <div
                      key={zone.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-all hover:shadow-sm ${
                        selectedZone.id === zone.id ? "ring-2 ring-primary bg-primary/5" : "bg-card"
                      }`}
                      onClick={() => setSelectedZone(zone)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-3 h-3 rounded-full ${getStatusColor(zone.status)} ${zone.status === "active" ? "animate-pulse" : ""}`}
                          ></div>
                          <span className="font-medium">{zone.name}</span>
                        </div>
                        {getStatusBadge(zone.status)}
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{zone.field}</p>
                      <div className="flex items-center justify-between text-sm">
                        <span>
                          Moisture: <span className={getMoistureColor(zone.soilMoisture)}>{zone.soilMoisture}%</span>
                        </span>
                        <span>Flow: {zone.waterFlow} GPM</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>

            {/* Zone Control Panel */}
            <div className="lg:col-span-2 space-y-4">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{selectedZone.name} Control</CardTitle>
                      <CardDescription>
                        {selectedZone.field} • {selectedZone.id}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" disabled={selectedZone.status === "maintenance"}>
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                      <Button variant="outline" size="sm" disabled={selectedZone.status !== "active"}>
                        <Pause className="h-4 w-4 mr-2" />
                        Pause
                      </Button>
                      <Button variant="outline" size="sm" disabled={selectedZone.status === "idle"}>
                        <Square className="h-4 w-4 mr-2" />
                        Stop
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Current Status */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                          <Droplets className="h-5 w-5 text-primary" />
                          <div>
                            <p className="text-sm text-muted-foreground">Soil Moisture</p>
                            <p className={`text-2xl font-bold ${getMoistureColor(selectedZone.soilMoisture)}`}>
                              {selectedZone.soilMoisture}%
                            </p>
                          </div>
                        </div>
                        <Progress value={selectedZone.soilMoisture} className="mt-2" />
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                          <Gauge className="h-5 w-5 text-secondary" />
                          <div>
                            <p className="text-sm text-muted-foreground">Water Flow</p>
                            <p className="text-2xl font-bold text-secondary">{selectedZone.waterFlow} GPM</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-2">
                          <Gauge className="h-5 w-5 text-chart-3" />
                          <div>
                            <p className="text-sm text-muted-foreground">Pressure</p>
                            <p className="text-2xl font-bold text-chart-3">{selectedZone.pressure} PSI</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Manual Control */}
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Manual Control</h4>
                      <div className="flex items-center space-x-2">
                        <Label htmlFor="auto-mode">Auto Mode</Label>
                        <Switch id="auto-mode" checked={autoMode} onCheckedChange={setAutoMode} />
                      </div>
                    </div>

                    {!autoMode && (
                      <div className="space-y-4 p-4 bg-muted/50 rounded-lg">
                        <div className="space-y-2">
                          <Label>Duration (minutes)</Label>
                          <Slider
                            value={manualDuration}
                            onValueChange={setManualDuration}
                            max={120}
                            min={5}
                            step={5}
                            className="w-full"
                          />
                          <div className="flex justify-between text-sm text-muted-foreground">
                            <span>5 min</span>
                            <span>{manualDuration[0]} minutes</span>
                            <span>120 min</span>
                          </div>
                        </div>
                        <Button className="w-full" disabled={selectedZone.status === "maintenance"}>
                          <Timer className="h-4 w-4 mr-2" />
                          Start Manual Irrigation ({manualDuration[0]} min)
                        </Button>
                      </div>
                    )}
                  </div>

                  {/* Zone Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h4 className="font-medium mb-2">Last Activity</h4>
                      <p className="text-sm text-muted-foreground">Last watered: {selectedZone.lastWatered}</p>
                      <p className="text-sm text-muted-foreground">Water used: {selectedZone.waterUsed} litres</p>
                      <p className="text-sm text-muted-foreground">Efficiency: {selectedZone.efficiency}%</p>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Next Scheduled</h4>
                      <p className="text-sm text-muted-foreground">{selectedZone.nextScheduled}</p>
                      <p className="text-sm text-muted-foreground">Duration: {selectedZone.duration} minutes</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Irrigation Schedule</CardTitle>
              <CardDescription>Automated irrigation scheduling based on soil conditions and weather</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Schedule Overview */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {irrigationZones.map((zone) => (
                    <Card key={zone.id}>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">{zone.name}</span>
                            {getStatusBadge(zone.status)}
                          </div>
                          <p className="text-sm text-muted-foreground">{zone.field}</p>
                          <div className="space-y-1">
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              <span className="text-xs">{zone.nextScheduled}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Timer className="h-3 w-3" />
                              <span className="text-xs">{zone.duration} minutes</span>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* Schedule Settings */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Auto Schedule Settings</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Moisture Threshold</Label>
                        <Select defaultValue="40">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="30">30% - Dry</SelectItem>
                            <SelectItem value="40">40% - Moderate</SelectItem>
                            <SelectItem value="50">50% - Conservative</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label>Preferred Time</Label>
                        <Select defaultValue="early">
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="early">Early Morning (5-7 AM)</SelectItem>
                            <SelectItem value="evening">Evening (6-8 PM)</SelectItem>
                            <SelectItem value="night">Night (10 PM - 4 AM)</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="weather-integration" defaultChecked />
                        <Label htmlFor="weather-integration">Weather Integration</Label>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Switch id="soil-sensors" defaultChecked />
                        <Label htmlFor="soil-sensors">Soil Sensor Override</Label>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Manual Schedule</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label>Zone</Label>
                        <Select>
                          <SelectTrigger>
                            <SelectValue placeholder="Select zone" />
                          </SelectTrigger>
                          <SelectContent>
                            {irrigationZones.map((zone) => (
                              <SelectItem key={zone.id} value={zone.id}>
                                {zone.name} - {zone.field}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="space-y-2">
                          <Label>Date</Label>
                          <Input type="date" />
                        </div>
                        <div className="space-y-2">
                          <Label>Time</Label>
                          <Input type="time" defaultValue="06:00" />
                        </div>
                      </div>
                      <div className="space-y-2">
                        <Label>Duration (minutes)</Label>
                        <Input type="number" defaultValue="30" min="5" max="120" />
                      </div>
                      <Button className="w-full">
                        <Calendar className="h-4 w-4 mr-2" />
                        Schedule Irrigation
                      </Button>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="monitoring" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Water Usage Trends</CardTitle>
                <CardDescription>Daily water consumption vs targets</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={waterUsageData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="day" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="usage" fill="#4B8E3B" />
                    <Bar dataKey="target" fill="#D9B300" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Soil Moisture Levels</CardTitle>
                <CardDescription>24-hour moisture monitoring</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={moistureData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="time" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="fieldA" stroke="#4B8E3B" strokeWidth={2} />
                    <Line type="monotone" dataKey="fieldB" stroke="#D9B300" strokeWidth={2} />
                    <Line type="monotone" dataKey="fieldC" stroke="#FF6B6B" strokeWidth={2} />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* System Alerts */}
          <Card>
            <CardHeader>
              <CardTitle>System Alerts</CardTitle>
              <CardDescription>Recent irrigation system notifications</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  { type: "warning", message: "Zone B-2 pressure low - check for blockages", time: "2 hours ago" },
                  { type: "info", message: "Scheduled irrigation completed for Zone A-1", time: "4 hours ago" },
                  { type: "success", message: "Water usage efficiency improved by 5%", time: "1 day ago" },
                  { type: "warning", message: "Soil moisture critically low in Field B-2", time: "1 day ago" },
                ].map((alert, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg">
                    {alert.type === "warning" && <AlertTriangle className="h-5 w-5 text-chart-3" />}
                    {alert.type === "info" && <Droplets className="h-5 w-5 text-primary" />}
                    {alert.type === "success" && <CheckCircle className="h-5 w-5 text-primary" />}
                    <div className="flex-1">
                      <p className="text-sm">{alert.message}</p>
                      <p className="text-xs text-muted-foreground">{alert.time}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>System Configuration</CardTitle>
                <CardDescription>Global irrigation system settings</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Water Pressure (PSI)</Label>
                  <Input type="number" defaultValue="30" min="20" max="50" />
                </div>
                <div className="space-y-2">
                  <Label>Flow Rate (GPM)</Label>
                  <Input type="number" defaultValue="25" min="10" max="50" />
                </div>
                <div className="space-y-2">
                  <Label>Emergency Contact</Label>
                  <Input type="tel" placeholder="+1 (555) 123-4567" />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="auto-shutoff" defaultChecked />
                  <Label htmlFor="auto-shutoff">Auto Emergency Shutoff</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Switch id="leak-detection" defaultChecked />
                  <Label htmlFor="leak-detection">Leak Detection</Label>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Maintenance Schedule</CardTitle>
                <CardDescription>System maintenance and calibration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  {[
                    { task: "Filter Replacement", due: "In 15 days", status: "upcoming" },
                    { task: "Pressure Calibration", due: "In 30 days", status: "upcoming" },
                    { task: "Sensor Cleaning", due: "Overdue by 2 days", status: "overdue" },
                    { task: "System Inspection", due: "In 45 days", status: "upcoming" },
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                      <div>
                        <p className="font-medium">{item.task}</p>
                        <p className="text-sm text-muted-foreground">{item.due}</p>
                      </div>
                      <Badge variant={item.status === "overdue" ? "destructive" : "outline"}>
                        {item.status === "overdue" ? "Overdue" : "Scheduled"}
                      </Badge>
                    </div>
                  ))}
                </div>
                <Button className="w-full">
                  <Settings className="h-4 w-4 mr-2" />
                  Schedule Maintenance
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
