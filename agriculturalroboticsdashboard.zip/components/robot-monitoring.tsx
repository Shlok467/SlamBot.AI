"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Tractor,
  Battery,
  MapPin,
  Thermometer,
  Droplets,
  Camera,
  Play,
  Pause,
  Square,
  RotateCcw,
  AlertTriangle,
  CheckCircle,
  Clock,
} from "lucide-react"

interface Robot {
  id: string
  name: string
  status: "active" | "idle" | "charging" | "maintenance" | "error"
  battery: number
  location: { x: number; y: number; field: string }
  task: string
  speed: number
  temperature: number
  lastUpdate: string
  sensors: {
    lidar: boolean
    camera: boolean
    soil: boolean
    gps: boolean
  }
  stats: {
    hoursWorked: number
    areasCovered: number
    tasksCompleted: number
  }
}

const mockRobots: Robot[] = [
  {
    id: "AGR-001",
    name: "Alpha Bot",
    status: "active",
    battery: 85,
    location: { x: 123.45, y: 67.89, field: "Field A-1" },
    task: "Crop Monitoring",
    speed: 3.7,
    temperature: 20,
    lastUpdate: "2 minutes ago",
    sensors: { lidar: true, camera: true, soil: true, gps: true },
    stats: { hoursWorked: 6.5, areasCovered: 12, tasksCompleted: 8 },
  },
  {
    id: "AGR-002",
    name: "Beta Bot",
    status: "active",
    battery: 92,
    location: { x: 234.56, y: 78.9, field: "Field B-2" },
    task: "Irrigation Control",
    speed: 2.9,
    temperature: 22,
    lastUpdate: "1 minute ago",
    sensors: { lidar: true, camera: true, soil: false, gps: true },
    stats: { hoursWorked: 4.2, areasCovered: 8, tasksCompleted: 5 },
  },
]

export function RobotMonitoring() {
  const [selectedRobot, setSelectedRobot] = useState<Robot>(mockRobots[0])

  const getStatusColor = (status: Robot["status"]) => {
    switch (status) {
      case "active":
        return "bg-primary"
      case "idle":
        return "bg-secondary"
      case "charging":
        return "bg-chart-2"
      case "maintenance":
        return "bg-chart-4"
      case "error":
        return "bg-destructive"
      default:
        return "bg-muted"
    }
  }

  const getStatusBadge = (status: Robot["status"]) => {
    switch (status) {
      case "active":
        return <Badge className="bg-primary">Active</Badge>
      case "idle":
        return <Badge variant="secondary">Idle</Badge>
      case "charging":
        return <Badge className="bg-chart-2 text-white">Charging</Badge>
      case "maintenance":
        return <Badge className="bg-chart-4 text-white">Maintenance</Badge>
      case "error":
        return <Badge variant="destructive">Error</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <div className="space-y-6">
      {/* Robot Fleet Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {mockRobots.map((robot) => (
          <Card
            key={robot.id}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedRobot.id === robot.id ? "ring-2 ring-primary" : ""
            }`}
            onClick={() => setSelectedRobot(robot)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-3 h-3 rounded-full ${getStatusColor(robot.status)} animate-pulse`}></div>
                  <CardTitle className="text-lg">{robot.name}</CardTitle>
                </div>
                {getStatusBadge(robot.status)}
              </div>
              <CardDescription>{robot.id}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Battery</span>
                  <div className="flex items-center gap-2">
                    <Battery className="h-4 w-4" />
                    <span className="font-medium">{robot.battery}%</span>
                  </div>
                </div>
                <Progress value={robot.battery} className="h-2" />

                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{robot.location.field}</span>
                </div>

                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">{robot.task}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Detailed Robot View */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Tractor className="h-5 w-5 text-primary" />
                {selectedRobot.name} - Detailed View
              </CardTitle>
              <CardDescription>Real-time monitoring and control</CardDescription>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" size="sm">
                <Play className="h-4 w-4 mr-2" />
                Start
              </Button>
              <Button variant="outline" size="sm">
                <Pause className="h-4 w-4 mr-2" />
                Pause
              </Button>
              <Button variant="outline" size="sm">
                <Square className="h-4 w-4 mr-2" />
                Stop
              </Button>
              <Button variant="outline" size="sm">
                <RotateCcw className="h-4 w-4 mr-2" />
                Return Home
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="status" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="status">Status</TabsTrigger>
              <TabsTrigger value="sensors">Sensors</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
              <TabsTrigger value="stats">Statistics</TabsTrigger>
            </TabsList>

            <TabsContent value="status" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Battery className="h-5 w-5 text-primary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Battery Level</p>
                        <p className="text-2xl font-bold">{selectedRobot.battery}%</p>
                      </div>
                    </div>
                    <Progress value={selectedRobot.battery} className="mt-2" />
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Thermometer className="h-5 w-5 text-secondary" />
                      <div>
                        <p className="text-sm text-muted-foreground">Temperature</p>
                        <p className="text-2xl font-bold">{selectedRobot.temperature}°C</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Tractor className="h-5 w-5 text-chart-3" />
                      <div>
                        <p className="text-sm text-muted-foreground">Speed</p>
                        <p className="text-2xl font-bold">{selectedRobot.speed} km/h</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2">
                      <Clock className="h-5 w-5 text-chart-4" />
                      <div>
                        <p className="text-sm text-muted-foreground">Last Update</p>
                        <p className="text-sm font-medium">{selectedRobot.lastUpdate}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Current Task</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{selectedRobot.task}</p>
                      <p className="text-sm text-muted-foreground">Location: {selectedRobot.location.field}</p>
                    </div>
                    {getStatusBadge(selectedRobot.status)}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="sensors" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(selectedRobot.sensors).map(([sensor, status]) => (
                  <Card key={sensor}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {sensor === "lidar" && <Camera className="h-5 w-5" />}
                          {sensor === "camera" && <Camera className="h-5 w-5" />}
                          {sensor === "soil" && <Droplets className="h-5 w-5" />}
                          {sensor === "gps" && <MapPin className="h-5 w-5" />}
                          <span className="capitalize font-medium">{sensor} Sensor</span>
                        </div>
                        {status ? (
                          <div className="flex items-center gap-1 text-primary">
                            <CheckCircle className="h-4 w-4" />
                            <span className="text-sm">Online</span>
                          </div>
                        ) : (
                          <div className="flex items-center gap-1 text-destructive">
                            <AlertTriangle className="h-4 w-4" />
                            <span className="text-sm">Offline</span>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="location" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>GPS Coordinates</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Latitude</p>
                      <p className="font-mono text-lg">{selectedRobot.location.x.toFixed(6)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Longitude</p>
                      <p className="font-mono text-lg">{selectedRobot.location.y.toFixed(6)}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Field Zone</p>
                      <p className="font-medium">{selectedRobot.location.field}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Placeholder for map */}
              <Card className="h-64">
                <CardContent className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">3D Field Map will be displayed here</p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="stats" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-primary">{selectedRobot.stats.hoursWorked}</p>
                    <p className="text-sm text-muted-foreground">Hours Worked Today</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-secondary">{selectedRobot.stats.areasCovered}</p>
                    <p className="text-sm text-muted-foreground">Areas Covered</p>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 text-center">
                    <p className="text-3xl font-bold text-chart-3">{selectedRobot.stats.tasksCompleted}</p>
                    <p className="text-sm text-muted-foreground">Tasks Completed</p>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
