"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  Area,
  AreaChart,
} from "recharts"
import { Leaf, TrendingUp, AlertTriangle, CheckCircle, Download } from "lucide-react"

const cropHealthData = [
  { field: "Field A-1", health: 92, yield: 85, disease: 0, pests: 0 },
  { field: "Field A-2", health: 78, yield: 80, disease: 12, pests: 2 }, // A-2 has disease present
  { field: "Field B-1", health: 95, yield: 90, disease: 0, pests: 0 },
]

const yieldTrendData = [
  { month: "Jan", predicted: 85, actual: 82 },
  { month: "Feb", predicted: 88, actual: 90 },
  { month: "Mar", predicted: 92, actual: 89 },
  { month: "Apr", predicted: 95, actual: 94 },
  { month: "May", predicted: 98, actual: 96 },
  { month: "Jun", predicted: 100, actual: 98 },
]

const diseaseDetectionData = [
  { name: "Healthy", value: 95, color: "#4B8E3B" },
  { name: "Bacterial wilt", value: 5, color: "#FF6B6B" },
]

const soilHealthData = [
  { field: "Field A-1", ph: 6.8, nitrogen: 85, phosphorus: 78, potassium: 92, moisture: 65 },
  { field: "Field A-2", ph: 6.5, nitrogen: 82, phosphorus: 75, potassium: 88, moisture: 58 },
  { field: "Field B-1", ph: 7.1, nitrogen: 90, phosphorus: 85, potassium: 95, moisture: 72 },
]

export function CropAnalytics() {
  const [selectedField, setSelectedField] = useState("all")
  const [timeRange, setTimeRange] = useState("7d")

  const getHealthColor = (health: number) => {
    if (health >= 90) return "text-primary"
    if (health >= 75) return "text-secondary"
    return "text-destructive"
  }

  const getHealthBadge = (health: number) => {
    if (health >= 90) return <Badge className="bg-primary">Excellent</Badge>
    if (health >= 75) return <Badge className="bg-secondary text-white">Good</Badge>
    if (health >= 60) return <Badge variant="outline">Fair</Badge>
    return <Badge variant="destructive">Poor</Badge>
  }

  return (
    <div className="space-y-6">
      {/* Controls */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-primary">Crop Analytics</h2>
          <p className="text-muted-foreground">AI-powered crop health monitoring and yield prediction</p>
        </div>
        <div className="flex gap-2">
          <Select value={selectedField} onValueChange={setSelectedField}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Select field" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Fields</SelectItem>
              <SelectItem value="field-a1">Field A-1</SelectItem>
              <SelectItem value="field-a2">Field A-2</SelectItem>
              <SelectItem value="field-b1">Field B-1</SelectItem>
            </SelectContent>
          </Select>
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">24 Hours</SelectItem>
              <SelectItem value="7d">7 Days</SelectItem>
              <SelectItem value="30d">30 Days</SelectItem>
              <SelectItem value="90d">90 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Leaf className="h-5 w-5 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">Avg Health Score</p>
                <p className="text-2xl font-bold text-primary">89%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-secondary" />
              <div>
                <p className="text-sm text-muted-foreground">Predicted Yield</p>
                <p className="text-2xl font-bold text-secondary">2,450 bu</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-chart-3" />
              <div>
                <p className="text-sm text-muted-foreground">Issues Detected</p>
                <p className="text-2xl font-bold text-chart-3">1</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-chart-4" />
              <div>
                <p className="text-sm text-muted-foreground">Fields Monitored</p>
                <p className="text-2xl font-bold text-chart-4">3/3</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="health" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="health">Crop Health</TabsTrigger>
          <TabsTrigger value="yield">Yield Prediction</TabsTrigger>
          <TabsTrigger value="disease">Disease Detection</TabsTrigger>
          <TabsTrigger value="soil">Soil Analysis</TabsTrigger>
          <TabsTrigger value="images">Field Images</TabsTrigger>
        </TabsList>

        <TabsContent value="health" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Field Health Overview */}
            <Card>
              <CardHeader>
                <CardTitle>Field Health Overview</CardTitle>
                <CardDescription>Current health status across all fields</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {cropHealthData.map((field) => (
                    <div key={field.field} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{field.field}</span>
                        {getHealthBadge(field.health)}
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex-1">
                          <Progress value={field.health} className="h-2" />
                        </div>
                        <span className={`font-bold ${getHealthColor(field.health)}`}>{field.health}%</span>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>Disease: {field.disease}%</span>
                        <span>Pests: {field.pests}%</span>
                        <span>Yield Est: {field.yield}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Health Trends Chart */}
            <Card>
              <CardHeader>
                <CardTitle>Health Trends</CardTitle>
                <CardDescription>Crop health over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <AreaChart data={yieldTrendData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="actual" stroke="#4B8E3B" fill="#4B8E3B" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="yield" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Yield Prediction Analysis</CardTitle>
              <CardDescription>AI-powered yield forecasting based on current conditions</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={yieldTrendData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="predicted" stroke="#D9B300" strokeWidth={2} strokeDasharray="5 5" />
                  <Line type="monotone" dataKey="actual" stroke="#4B8E3B" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="disease" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Disease Distribution</CardTitle>
                <CardDescription>Current disease detection across fields</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={diseaseDetectionData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    >
                      {diseaseDetectionData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Disease Alerts</CardTitle>
                <CardDescription>Recent disease detections requiring attention</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[{ field: "Field A-2", disease: "Bacterial wilt", severity: "Medium", detected: "3 hours ago" }].map(
                    (alert, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                        <div>
                          <p className="font-medium">{alert.disease}</p>
                          <p className="text-sm text-muted-foreground">
                            {alert.field} • {alert.detected}
                          </p>
                        </div>
                        <Badge variant="secondary">{alert.severity}</Badge>
                      </div>
                    ),
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="soil" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Soil Health Analysis</CardTitle>
              <CardDescription>Comprehensive soil condition monitoring</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {soilHealthData.map((field) => (
                  <div key={field.field} className="space-y-3">
                    <h4 className="font-medium">{field.field}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">pH Level</p>
                        <p className="text-lg font-bold">{field.ph}</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Nitrogen</p>
                        <p className="text-lg font-bold text-primary">{field.nitrogen}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Phosphorus</p>
                        <p className="text-lg font-bold text-secondary">{field.phosphorus}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Potassium</p>
                        <p className="text-lg font-bold text-chart-3">{field.potassium}%</p>
                      </div>
                      <div className="text-center">
                        <p className="text-sm text-muted-foreground">Moisture</p>
                        <p className="text-lg font-bold text-chart-4">{field.moisture}%</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="images" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[
              {
                field: "Field A-1",
                timestamp: "2 hours ago",
                status: "Healthy",
                confidence: 95,
                src: "/images/black-cardamom.jpg",
                alt: "Black cardamom plants under canopy",
              },
              {
                field: "Field A-2",
                timestamp: "3 hours ago",
                status: "Disease Detected",
                confidence: 92,
                src: "/images/bacterial-wilt-ginger.jpg",
                alt: "Ginger leaves showing bacterial wilt symptoms",
                disease: "Bacterial wilt",
              },
              {
                field: "Field A-3",
                timestamp: "4 hours ago",
                status: "Healthy",
                confidence: 90,
                src: "/images/maize.jpg",
                alt: "Maize crop with mature cobs",
              },
            ].map((image, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="aspect-video rounded-lg mb-3 overflow-hidden">
                    <img src={image.src || "/placeholder.svg"} alt={image.alt} className="w-full h-full object-cover" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{image.field}</span>
                      <Badge variant={image.status === "Healthy" ? "default" : "destructive"}>{image.status}</Badge>
                    </div>
                    {image.disease ? <p className="text-sm text-destructive">Detected: {image.disease}</p> : null}
                    <p className="text-sm text-muted-foreground">{image.timestamp}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">AI Confidence:</span>
                      <span className="text-sm font-medium">{image.confidence}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
