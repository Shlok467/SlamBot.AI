"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, ChevronLeft, ChevronRight } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

function Calendar({
  selected,
  onSelect,
  disabled,
  mode = "single",
  initialFocus = false,
}: {
  selected?: Date
  onSelect?: (date: Date) => void
  disabled?: (date: Date) => boolean
  mode?: string
  initialFocus?: boolean
}) {
  const [currentMonth, setCurrentMonth] = useState(selected || new Date())
  const [selectedYear, setSelectedYear] = useState(currentMonth.getFullYear())

  const daysInMonth = new Date(selectedYear, currentMonth.getMonth() + 1, 0).getDate()
  const firstDayOfMonth = new Date(selectedYear, currentMonth.getMonth(), 1).getDay()

  const days = []

  for (let i = 0; i < firstDayOfMonth; i++) {
    days.push(<div key={`empty-${i}`} className="p-2"></div>)
  }

  for (let day = 1; day <= daysInMonth; day++) {
    const date = new Date(selectedYear, currentMonth.getMonth(), day)
    const isSelected = selected && date.toDateString() === selected.toDateString()
    const isDisabled = disabled?.(date)

    days.push(
      <button
        key={day}
        onClick={() => !isDisabled && onSelect?.(date)}
        disabled={isDisabled}
        className={cn(
          "p-2 text-sm rounded hover:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed",
          isSelected && "bg-blue-600 text-white hover:bg-blue-700",
        )}
      >
        {day}
      </button>,
    )
  }

  const previousMonth = () => {
    setCurrentMonth(new Date(selectedYear, currentMonth.getMonth() - 1))
  }

  const nextMonth = () => {
    setCurrentMonth(new Date(selectedYear, currentMonth.getMonth() + 1))
  }

  const currentYear = new Date().getFullYear()
  const yearOptions = []
  for (let year = 1900; year <= currentYear; year++) {
    yearOptions.push(year)
  }

  return (
    <div className="p-3">
      <div className="mb-4">
        <Label className="text-xs text-slate-600 mb-2 block">Select Year</Label>
        <Select
          value={selectedYear.toString()}
          onValueChange={(value) => {
            const year = Number.parseInt(value)
            setSelectedYear(year)
            setCurrentMonth(new Date(year, currentMonth.getMonth()))
          }}
        >
          <SelectTrigger className="w-full">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="max-h-48">
            {yearOptions.reverse().map((year) => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between mb-4">
        <button onClick={previousMonth} className="p-1 hover:bg-gray-100 rounded">
          <ChevronLeft className="h-4 w-4" />
        </button>
        <h3 className="font-semibold">{format(new Date(selectedYear, currentMonth.getMonth()), "MMMM yyyy")}</h3>
        <button onClick={nextMonth} className="p-1 hover:bg-gray-100 rounded">
          <ChevronRight className="h-4 w-4" />
        </button>
      </div>
      <div className="grid grid-cols-7 gap-1 mb-2">
        {["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"].map((day) => (
          <div key={day} className="p-2 text-xs font-medium text-center text-gray-500">
            {day}
          </div>
        ))}
      </div>
      <div className="grid grid-cols-7 gap-1">{days}</div>
    </div>
  )
}

interface UserProfileModalProps {
  children: React.ReactNode
}

export function UserProfileModal({ children }: UserProfileModalProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: "John Doe",
    email: "john.doe@farmtech.com",
    phone: "+1 (555) 123-4567",
    location: "California, USA",
    role: "Farm Manager",
    department: "Operations",
    joinDate: new Date(2023, 0, 15), // January 15, 2023
    bio: "Experienced farm manager with 15+ years in agricultural technology and sustainable farming practices.",
    avatar: "/diverse-farmers-harvest.png",
  })

  const [editedProfile, setEditedProfile] = useState(profile)

  const handleSave = () => {
    setProfile(editedProfile)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditedProfile(profile)
    setIsEditing(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <span>User Profile</span>
            <div className="flex gap-2">
              {isEditing ? (
                <>
                  <Button onClick={handleSave} size="sm" className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                  <Button onClick={handleCancel} variant="outline" size="sm">
                    Cancel
                  </Button>
                </>
              ) : (
                <Button onClick={() => setIsEditing(true)} size="sm" variant="outline">
                  Edit Profile
                </Button>
              )}
            </div>
          </DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="activity">Activity</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>
                  {isEditing ? "Edit your personal details" : "Your personal information"}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Avatar className="h-20 w-20">
                      <AvatarImage src={editedProfile.avatar || "/placeholder.svg"} />
                      <AvatarFallback className="text-lg bg-blue-100 text-blue-700">
                        {editedProfile.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                    {isEditing && (
                      <Button
                        size="sm"
                        variant="outline"
                        className="absolute -bottom-2 -right-2 h-8 w-8 rounded-full p-0 bg-transparent"
                      >
                        <CalendarIcon className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-lg font-semibold text-slate-900">{profile.name}</h3>
                    <p className="text-sm text-slate-600">{profile.role}</p>
                    <Badge variant="secondary">{profile.department}</Badge>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Full Name
                    </Label>
                    {isEditing ? (
                      <Input
                        id="name"
                        value={editedProfile.name}
                        onChange={(e) => setEditedProfile({ ...editedProfile, name: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">{profile.name}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Email Address
                    </Label>
                    {isEditing ? (
                      <Input
                        id="email"
                        type="email"
                        value={editedProfile.email}
                        onChange={(e) => setEditedProfile({ ...editedProfile, email: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">{profile.email}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Phone Number
                    </Label>
                    {isEditing ? (
                      <Input
                        id="phone"
                        value={editedProfile.phone}
                        onChange={(e) => setEditedProfile({ ...editedProfile, phone: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">{profile.phone}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Location
                    </Label>
                    {isEditing ? (
                      <Input
                        id="location"
                        value={editedProfile.location}
                        onChange={(e) => setEditedProfile({ ...editedProfile, location: e.target.value })}
                      />
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">{profile.location}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="role" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Role
                    </Label>
                    {isEditing ? (
                      <Select
                        value={editedProfile.role}
                        onValueChange={(value) => setEditedProfile({ ...editedProfile, role: value })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Farm Manager">Farm Manager</SelectItem>
                          <SelectItem value="Agricultural Technician">Agricultural Technician</SelectItem>
                          <SelectItem value="Operations Supervisor">Operations Supervisor</SelectItem>
                          <SelectItem value="Field Coordinator">Field Coordinator</SelectItem>
                        </SelectContent>
                      </Select>
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">{profile.role}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="joinDate" className="flex items-center gap-2">
                      <CalendarIcon className="h-4 w-4" />
                      Join Date
                    </Label>
                    {isEditing ? (
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !editedProfile.joinDate && "text-muted-foreground",
                            )}
                          >
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {editedProfile.joinDate ? format(editedProfile.joinDate, "PPP") : <span>Pick a date</span>}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={editedProfile.joinDate}
                            onSelect={(date) => date && setEditedProfile({ ...editedProfile, joinDate: date })}
                            disabled={(date) => date > new Date() || date < new Date("1900-01-01")}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    ) : (
                      <p className="text-sm text-slate-700 p-2 bg-slate-50 rounded">
                        {format(profile.joinDate, "PPP")}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio">Bio</Label>
                  {isEditing ? (
                    <Textarea
                      id="bio"
                      value={editedProfile.bio}
                      onChange={(e) => setEditedProfile({ ...editedProfile, bio: e.target.value })}
                      rows={3}
                    />
                  ) : (
                    <p className="text-sm text-slate-700 p-3 bg-slate-50 rounded">{profile.bio}</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Preferences</CardTitle>
                <CardDescription>Customize your dashboard experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Temperature Unit</Label>
                  <Select defaultValue="celsius">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="celsius">Celsius (°C)</SelectItem>
                      <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Notification Preferences</Label>
                  <div className="space-y-2">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Email notifications</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Emergency alerts</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Weekly reports</span>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activity" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your recent actions and system interactions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg border border-border">
                    <div className="h-2 w-2 bg-blue-500 rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Updated irrigation schedule</p>
                      <p className="text-xs text-muted-foreground">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg border border-border">
                    <div className="h-2 w-2 bg-muted-foreground rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Reviewed crop analytics report</p>
                      <p className="text-xs text-muted-foreground">1 day ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3 p-3 bg-muted/50 rounded-lg border border-border">
                    <div className="h-2 w-2 bg-muted-foreground rounded-full"></div>
                    <div>
                      <p className="text-sm font-medium text-foreground">Deployed robot to Field A</p>
                      <p className="text-xs text-muted-foreground">3 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  )
}
