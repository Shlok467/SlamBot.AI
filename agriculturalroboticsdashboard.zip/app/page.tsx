"use client"

import { useState } from "react"
import { Sidebar } from "@/components/sidebar"
import { Header } from "@/components/header"
import { DashboardGrid } from "@/components/dashboard-grid"
import { FieldMap3D } from "@/components/field-map-3d"
import { CropAnalytics } from "@/components/crop-analytics"
import { IrrigationControls } from "@/components/irrigation-controls"
import { RobotMonitoring } from "@/components/robot-monitoring"
import { EmergencySystem } from "@/components/emergency-system"

export default function Dashboard() {
  const [activeSection, setActiveSection] = useState("dashboard")

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return <DashboardGrid />
      case "analytics":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">Crop Analytics</h1>
            <CropAnalytics />
          </div>
        )
      case "irrigation":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">Irrigation Management</h1>
            <IrrigationControls />
          </div>
        )
      case "field-map":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">3D Field Map</h1>
            <FieldMap3D />
          </div>
        )
      case "robot-fleet":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">Robot Fleet</h1>
            <RobotMonitoring />
          </div>
        )
      case "alerts":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">Emergency Alerts</h1>
            <EmergencySystem />
          </div>
        )
      case "settings":
        return (
          <div className="space-y-6">
            <h1 className="text-3xl font-bold text-primary">Settings</h1>
            <div className="bg-card p-6 rounded-lg border">
              <p className="text-muted-foreground">Settings panel coming soon...</p>
            </div>
          </div>
        )
      default:
        return <DashboardGrid />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <Sidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header />
        <main className="flex-1 overflow-auto p-6">{renderContent()}</main>
      </div>
    </div>
  )
}
