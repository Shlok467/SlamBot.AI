import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({
    robots: [
      {
        id: "AGR-001",
        name: "Alpha",
        x: 45,
        y: 40,
        z: 1,
        heading: 45,
        field: "Field A-1",
        lat: 27.1067,
        lng: 88.3233,
      },
      {
        id: "AGR-002",
        name: "Beta",
        x: 155,
        y: 45,
        z: 2,
        heading: 180,
        field: "Field A-2",
        lat: 27.1082,
        lng: 88.3211,
      },
    ],
  })
}
