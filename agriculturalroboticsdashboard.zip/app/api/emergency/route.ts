import { NextResponse } from "next/server"

export async function GET() {
  return NextResponse.json({ name: "Farm Manager", phone: "+91 8591619938" })
}
