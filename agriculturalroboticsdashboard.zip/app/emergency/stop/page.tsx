"use client"

import useSWR from "swr"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { AlertTriangle, MapPin, ArrowLeft } from "lucide-react"
import Link from "next/link"
import { useEffect } from "react"
import { useRouter } from "next/navigation"

const fetcher = (url: string) => fetch(url).then((r) => r.json())

export default function EmergencyStopPage() {
  const { data } = useSWR<{
    robots: Array<{ id: string; name: string; lat?: number; lng?: number }>
  }>("/api/robots", fetcher)

  const robots = data?.robots?.length
    ? data.robots
    : [
        { id: "alpha", name: "Alpha", lat: 27.1067, lng: 88.3233 },
        { id: "beta", name: "Beta", lat: 27.1082, lng: 88.3211 },
      ]

  const router = useRouter()
  useEffect(() => {
    router.prefetch("/")
  }, [router])

  return (
    <main className="p-6 max-w-6xl mx-auto space-y-6">
      <Card className="border-destructive/40 bg-destructive/5">
        <CardHeader>
          <CardTitle className="text-destructive flex items-center gap-2">
            <AlertTriangle className="h-6 w-6" />
            Emergency Stop Activated
          </CardTitle>
          <CardDescription>
            All systems have received the stop signal. Robot locations are shown below. Use the button below to return
            to the dashboard when you're ready.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {robots.map((r) => {
          const lat = r.lat ?? 27.1067
          const lng = r.lng ?? 88.3233
          const label = encodeURIComponent(`${r.name} - Jorethang`)
          const mapsLink = `https://www.google.com/maps/search/?api=1&query=${lat},${lng} (${label})`

          return (
            <Card key={r.id}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MapPin className="h-5 w-5" />
                  {r.name}
                </CardTitle>
                <CardDescription className="font-mono">
                  {lat}, {lng}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="text-sm text-muted-foreground">
                  <span className="font-mono">
                    {lat}, {lng}
                  </span>{" "}
                  • Jorethang region
                </div>
                <Button
                  variant="outline"
                  onClick={() => window.open(mapsLink, "_blank", "noopener,noreferrer")}
                  aria-label={`Open ${r.name} in Google Maps`}
                >
                  <MapPin className="h-4 w-4 mr-2" />
                  Open in Google Maps
                </Button>
              </CardContent>
            </Card>
          )
        })}
      </div>

      <div className="text-center">
        <Button asChild aria-label="Back to Dashboard">
          <Link href="/" prefetch>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
      </div>
    </main>
  )
}
